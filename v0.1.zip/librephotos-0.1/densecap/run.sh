th webcam/daemon.lua
python webcam/server.py

output directory for client/server webcam demo

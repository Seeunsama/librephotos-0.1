input directory for client/server webcam demo

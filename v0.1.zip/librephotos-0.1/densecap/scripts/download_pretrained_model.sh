mkdir -p data/models/densecap
cd data/models/densecap
wget http://cs.stanford.edu/people/jcjohns/densecap/densecap-pretrained-vgg16.t7.zip
unzip densecap-pretrained-vgg16.t7.zip
rm densecap-pretrained-vgg16.t7.zip
cd ../../../

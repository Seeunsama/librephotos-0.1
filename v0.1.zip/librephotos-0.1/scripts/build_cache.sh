curl -u 'admin:q1W@e3R$' http://localhost:8000/api/faces/ >> /dev/null
curl -u 'admin:q1W@e3R$' http://localhost:8000/api/faces/labeled/ >> /dev/null
curl -u 'admin:q1W@e3R$' http://localhost:8000/api/faces/inferred/ >> /dev/null

curl -u 'admin:q1W@e3R$' http://localhost:8000/api/albums/auto/list/ >> /dev/null
curl -u 'admin:q1W@e3R$' http://localhost:8000/api/albums/person/list/ >> /dev/null
curl -u 'admin:q1W@e3R$' http://localhost:8000/api/albums/date/list/ >> /dev/null
